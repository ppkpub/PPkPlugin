//-------------------- 右键菜单演示 ------------------------//
chrome.contextMenus.create({
	title: "刷新PPk资源缓存",
	onclick: function(){
    /*
		chrome.notifications.create(null, {
			type: 'basic',
			iconUrl: 'img/icon.png',
			title: '这是标题',
			message: '您刚才点击了自定义右键菜单！'
		});
    */
    //PPKPIB.clearCache();
    getCurrentTabId(tabId => {
      chrome.tabs.sendMessage(tabId, {cmd:'refresh_ppk_cache'} , function(response)
      {
        console.log('refresh_ppk_cache已响应完成 tabId='+tabId);;
      });
    })
  
    
	}
});

chrome.contextMenus.create({
	title: '使用PPk访问：%s', // %s表示选中的文字
	contexts: ['selection'], // 只有当选中文字时才会出现此右键菜单
	onclick: function(params)
	{
		// 注意不能使用location.href，因为location是属于background的window对象
		chrome.tabs.create({url: 'http://ppk001.sinaapp.com/demo/browser/?go=' + encodeURIComponent(params.selectionText)});
	}
});


//-------------------- badge演示 ------------------------//
/*(function()
{
	var showBadge = false;
	var menuId = chrome.contextMenus.create({
		title: '显示图标上的Badge',
		type: 'checkbox',
		checked: false,
		onclick: function() {
			if(!showBadge)
			{
				chrome.browserAction.setBadgeText({text: 'New'});
				chrome.browserAction.setBadgeBackgroundColor({color: [255, 0, 0, 255]});
				chrome.contextMenus.update(menuId, {title: '隐藏图标上的Badge', checked: true});
			}
			else
			{
				chrome.browserAction.setBadgeText({text: ''});
				chrome.browserAction.setBadgeBackgroundColor({color: [0, 0, 0, 0]});
				chrome.contextMenus.update(menuId, {title: '显示图标上的Badge', checked: false});
			}
			showBadge = !showBadge;
		}
	});
})();*/

// 监听来自content-script的消息
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse)
{
	console.log('收到来自content-script的消息：');
	//console.log(request, sender, sendResponse);
	
    if(request.cmd == 'get_ppk_data'){
        getPPkData(request, sender, sendResponse);
    }else if(request.cmd == 'del_ppk_cache'){
        delPPkCache(request, sender, sendResponse);
    }else if(request.cmd == 'get_current_user'){
        getCurrentUser(request, sender, sendResponse);
    }else{
        sendResponse('我是后台，我已收到你的消息：' + JSON.stringify(request));
    }
});

async function getPPkData( request, sender, sendResponse ) {
    var resp_status="";
    var resp_result=null;
    PPKLIB.getPPkData(
        request.uri,
        function(status,result){
            resp_status = status;
            resp_result = result;
        }, 
        true
    );
    var couter=0;
    while(resp_status=="" && couter<30){
        await sleepInAsyncFunction(100);
        couter++;
    }
    
    sendResponse({"status":resp_status,"result":resp_result});
    
}

function delPPkCache( request, sender, sendResponse ) {
    PPKLIB.deleteCache( request.uri );
    
    sendResponse({"status":"OK","result":"deled PPkCache of "+request.uri});
}

function sleepInAsyncFunction(millisecond) {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve()
        }, millisecond)
    })
}

function getCurrentUser( request, sender, sendResponse ) {
    var resp_status="OK";
    var resp_result=getCurrentUserInfo();
    
    if(resp_result!=null)
      sendResponse({"status":"OK","result":resp_result});
    else
      sendResponse({"status":"NotExisted"});
}

$('#test_get_ppk_data').click((e) => {
	PPKLIB.getPPkData(
        "ppk:106256",
        testPPkDataCallback,
        true
    );
});

function testPPkDataCallback(status,result){
    alert('status='+status+"\nresult="+result);
}

$('#test_cors').click((e) => {
	$.get('https://www.baidu.com', function(html){
		console.log( html);
		alert('跨域调用成功！');
	});
});

$('#get_popup_title').click(e => {
	var views = chrome.extension.getViews({type:'popup'});
	if(views.length > 0) {
		alert(views[0].document.title);
	} else {
		alert('popup未打开！');
	}
});

// 获取当前选项卡ID
function getCurrentTabId(callback)
{
	chrome.tabs.query({active: true, currentWindow: true}, function(tabs)
	{
		if(callback) callback(tabs.length ? tabs[0].id: null);
	});
}

// 当前标签打开某个链接
function openUrlCurrentTab(url)
{
	getCurrentTabId(tabId => {
		chrome.tabs.update(tabId, {url: url});
	})
}

// 新标签打开某个链接
function openUrlNewTab(url)
{
	chrome.tabs.create({url: url});
}

// omnibox 演示
chrome.omnibox.onInputChanged.addListener((text, suggest) => {
	console.log('inputChanged: ' + text);
	if(!text) return;
	if( text == '分布式微博' ||  text == '长毛象' || text.toLowerCase() == 'mastodon') {
		suggest([
            {content: '分布式微博(中文) mao.mastodonhub.com', description: '分布式微博(中文) mao.mastodonhub.com'},
			{content: '分布式微博(英文) mstdn.jp', description: '分布式微博(英文) mstdn.jp'},
			{content: '分布式微博(日文) mastodon.online' , description: '分布式微博(日文) mastodon.online'},
		]);
	}
    else if(text == '微博') {
		suggest([
			{content: '新浪' + text, description: '新浪' + text},
			{content: '腾讯' + text, description: '腾讯' + text},
			{content: '搜狐' + text, description: '搜索' + text},
		]);
	}
	else {
		suggest([
			{content: '转账给 ppk:' + text, description: '转账给 ppk:' + text},
			{content: '访问主页 ppk:' + text+"/", description: '访问主页 ppk:' + text + "/"},
		]);
	}
});

// 当用户接收关键字建议时触发
chrome.omnibox.onInputEntered.addListener((text) => {
    console.log('inputEntered: ' + text);
	if(!text) return;
    
    var href = '';
    
    if(text.startsWith('分布式微博')){
        href = "https://"+text.substring(text.indexOf(" ")+1);
    }else{
        var matched_ppk_uris = PPKLIB.fetchPPkURIs(text);

        if(matched_ppk_uris==null || matched_ppk_uris.length==0 ){
            href = 'http://ppk001.sinaapp.com/demo/browser/?go=' + encodeURIComponent(text);
        }else{
            var tmp_ppk_uri = matched_ppk_uris[0];
            if(text.startsWith('转账给')) 
                href = 'https://ppk001.sinaapp.com/odin/?me=' + encodeURIComponent(tmp_ppk_uri);
            else if(text.startsWith('访问主页')) 
                href = 'http://ppk001.sinaapp.com/demo/browser/?go=' + encodeURIComponent(tmp_ppk_uri);
            else 
                href = 'http://ppk001.sinaapp.com/demo/browser/?go=' + encodeURIComponent(tmp_ppk_uri);
        }   
    }
    
	openUrlCurrentTab(href);
});

// 预留给popup调用的测试方法
function testBackground() {
	alert('你好，我是background！');
}

function getCurrentUserInfo() {
  //var local_encrypted=getLocalConfigData('local_encrypted');
  //var local_prvkey_encrypted=getLocalConfigData('local_prvkey_encrypted');
  var local_address=getLocalConfigData('local_address');
  var local_odin=PPKLIB.formatPPkURI(getLocalConfigData('local_odin'),false);
  //var local_txfee=getLocalConfigData('local_txfee');
  //console.log("local_odin="+local_odin+"\nlocal_encrypted="+local_encrypted+"\nlocal_prvkey_encrypted="+local_prvkey_encrypted+"\nlocal_address="+local_address+"\nlocal_txfee="+local_txfee);
  
  //gBoolEncrypted = (local_encrypted=='ON');
  
  if(local_odin==null)
      return null;
  
  return {"uri":local_odin,"register":local_address};
}

// 读取是否显示图片的设置
var showImage;
chrome.storage.sync.get({showImage: true}, function(items) {
	showImage = items.showImage;
});

/*
//Test
var eventList = ['onBeforeNavigate', 'onCreatedNavigationTarget',
    'onCommitted', 'onCompleted', 'onDOMContentLoaded',
    'onErrorOccurred', 'onReferenceFragmentUpdated', 'onTabReplaced',
    'onHistoryStateUpdated'];

eventList.forEach(function(e) {
  chrome.webNavigation[e].addListener(function(data) {
    if (typeof data)
      console.log(chrome.i18n.getMessage('inHandler'), e, data);
    else
      console.error(chrome.i18n.getMessage('inHandlerError'), e);
  });
});
*/

//web浏览监听
chrome.webNavigation.onBeforeNavigate.addListener(function(data) {
    if (typeof data){
      console.log(chrome.i18n.getMessage('inHandler'), "onBeforeNavigate", data);
      if( typeof data.url ){
         console.log("onBeforeNavigate data.url=", data.url );  
         
         data.url=data.url.replace("：",":"); //替换容易输错的字符
         
         var tmp_ppk_uri = null;
         var pattern = /http:\/\/[pP][pP][kK]:\w+([\w-./]*)?/;
         var matched_ppk_uris = pattern.exec(data.url);
         if(matched_ppk_uris!=null && matched_ppk_uris[0].length >0){
             tmp_ppk_uri = matched_ppk_uris[0].substring(7,matched_ppk_uris[0].length-1);
             
             tmp_ppk_uri = PPKLIB.formatPPkURI(tmp_ppk_uri,false);
         }else{
             pattern = /search\?q=[pP][pP][kK]:\w+([\w-./]*)?/;
             var matched_ppk_uris = pattern.exec( decodeURIComponent(data.url) );
             if(matched_ppk_uris!=null && matched_ppk_uris[0].length >0){
                 tmp_ppk_uri = matched_ppk_uris[0].substring(9);
                 tmp_ppk_uri = PPKLIB.formatPPkURI(tmp_ppk_uri,true);
             }
         }
         
         
         if(tmp_ppk_uri!=null){
            console.log("onBeforeNavigate matched ppk uri=", tmp_ppk_uri);  
            
            chrome.tabs.update(data.tabId,{url: 'http://ppk001.sinaapp.com/demo/browser/?go=' + encodeURIComponent(tmp_ppk_uri)});
         }
      }
    }else
      console.error(chrome.i18n.getMessage('inHandlerError'),  "onBeforeNavigate");
});


/*
//web请求监听，最后一个参数表示阻塞式，需单独声明权限：webRequestBlocking
chrome.webRequest.onBeforeRequest.addListener(details => {
	// cancel 表示取消本次请求
	if(!showImage && details.type == 'image') return {cancel: true};
	// 简单的音视频检测
	// 大部分网站视频的type并不是media，且视频做了防下载处理，所以这里仅仅是为了演示效果，无实际意义
	if(details.type == 'media') {
		chrome.notifications.create(null, {
			type: 'basic',
			iconUrl: 'img/icon.png',
			title: '检测到音视频',
			message: '音视频地址：' + details.url,
		});
	}
}, {urls: ["<all_urls>"]}, ["blocking"]);
*/
/*
//web完成结果监听
chrome.webRequest.onCompleted.addListener(
  function (details) {
    if (details.statusCode == 200 && details.type != 'image') {
        console.log("webRequest.onCompleted details="+ JSON.stringify(details));
        chrome.tabs.sendMessage(details.tabId, {cmd:'web_request_ok', keys: ['@ppk:','$ppk:']} , function(response)
		{
			console.log('webRequest_response已响应完成');;
		});
    }
  },

  { urls: ["<all_urls>"] }  //监听页面请求,你也可以通过*来匹配。
);
*/