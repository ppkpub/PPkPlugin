﻿//缓存奥丁号信息
var g_mapPPkOdinInfo=new Map();

console.log('Inject PPkPlugin content-script!');

// 注意，必须设置了run_at=document_start 此段代码才会生效
document.addEventListener('DOMContentLoaded', function()
{
	// 注入自定义JS
	//injectCustomJs();
    
	// 处理网址示例，给谷歌搜索结果的超链接增加 _target="blank"
	if(location.host == 'www.google.com.tw')
	{
		var objs = document.querySelectorAll('h3.r a');
		for(var i=0; i<objs.length; i++)
		{
			objs[i].setAttribute('_target', 'blank');
		}
		console.log('已处理谷歌超链接！');
	}

  refreshPPkCodes();;
});


// 向页面注入JS
function injectCustomJs(jsPath)
{
	jsPath = jsPath || 'js/inject.js';
	var temp = document.createElement('script');
	temp.setAttribute('type', 'text/javascript');
	// 获得的地址类似：chrome-extension://ihcokhadfjfchaeagdoclpnjdiokfakg/js/inject.js
	temp.src = chrome.extension.getURL(jsPath);
	temp.onload = function()
	{
		// 放在页面不好看，执行完后移除掉
		this.parentNode.removeChild(this);
	};
	document.body.appendChild(temp);
}

// 接收来自后台的消息
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse)
{
	console.log('收到来自 ' + (sender.tab ? "content-script(" + sender.tab.url + ")" : "popup或者background") + ' 的消息：', request);
	if(request.cmd == 'update_font_size') {
		var ele = document.createElement('style');
		ele.innerHTML = `* {font-size: ${request.size}px !important;}`;
      document.head.appendChild(ele);
  }
  else if(request.cmd == 'refresh_ppk_cache') {
    //遍历删除background的缓存
    console.log("refresh_ppk_cache size="+g_mapPPkOdinInfo.size );  
    for(let tmp_ppk_uri of g_mapPPkOdinInfo.keys()){
        console.log("delete cache",tmp_ppk_uri);  
        delPPkCacheByBackground(tmp_ppk_uri);
    }

    g_mapPPkOdinInfo.clear();
  }
  else if(request.cmd == 'update_ppk_code') {
    refreshPPkCodes();
  }
  else if(request.cmd == 'web_request_ok') {
    refreshPPkCodes();
    sendResponse('web_request_ok end');
  }
	else {
		tip(JSON.stringify(request));
		sendResponse('我收到你的消息了：'+JSON.stringify(request));
	}
});

var ppk_refresh_delay=0;
function refreshPPkCodes( ) {
    console.log("refreshPPkCodes() ppk_refresh_delay="+ppk_refresh_delay);

    if(location.href.indexOf('weibo.com')>0){
      updateForSinaWeibo();
    }else if(location.href.indexOf('binance')>0){
      updateForExchangeBinance();
    }else{
      updateForMastodon(); 
    }
    
    if(ppk_refresh_delay<5000)
        ppk_refresh_delay += 500;
    
    setTimeout(refreshPPkCodes, ppk_refresh_delay );
}

function pendingOdinInfo(tmp_ppk_uri){
    var result_data=g_mapPPkOdinInfo.get(tmp_ppk_uri);
    if( typeof(result_data)=="undefined" ){
        //Meet new ODIN
        console.log("pendingOdinInfo() fetching new odin="+tmp_ppk_uri );
        result_data=null;
        g_mapPPkOdinInfo.set(tmp_ppk_uri,result_data);
        
        getPPkDataByBackground(
            tmp_ppk_uri,
            function(status,result){
                g_mapPPkOdinInfo.set( tmp_ppk_uri,parseRespPPkData(status,result) );
                //refreshPPkCodes();
            }, 
            true);
        /*     
        var couter=0;
        while(couter<30){
            console.log("pendingOdinInfo["+tmp_ppk_uri+"] couter="+couter);
            result_data = g_mapPPkOdinInfo.get(tmp_ppk_uri);
            if(result_data!=null)
                break;
            
            await sleepInAsyncFunction(100);
            couter++;
        }
        await sleepInAsyncFunction(3000);
        console.log("pendingOdinInfo["+tmp_ppk_uri+"] end. result_data="+result_data);
        
        refreshPPkCodes();
        */
    }
    
    return result_data;
}

function getOdinRedirectSnsId(tmp_ppk_uri,sns_type){
    var result_data=pendingOdinInfo(tmp_ppk_uri);;
    
    if(result_data==null || result_data.x_sns==null)
        return null;
      
    console.log("getOdinRedirectSnsId","result_data.x_sns=", JSON.stringify(result_data.x_sns));
    
    var tmp_ids = result_data.x_sns[sns_type];
    if( typeof(tmp_ids)=="undefined" || tmp_ids==null || tmp_ids.length==0)
      return null;

    return tmp_ids[0];
}

//for Mastodon
function updateForMastodon( ) {
    console.log("updateForMastodon() ");
    
    updateForMastodonSendEvent( );
    
    updateForMastodonListClass("status");
    updateForMastodonListClass("account");
    updateForMastodonListClass("detailed-status");
    updateForMastodonNotifTitle();
    updateForMastodonAccountHeader();
    updateForMastodonText("status__content__text");
    
}

function updateForMastodonSendEvent(  ){
    var parent_element=getFirstElementByClassName(document,"compose-form__publish-button-wrapper");
    
    if(parent_element!=null){
        var ppk_button_element=getFirstElementByClassName(parent_element,"button button-send-ppk");
        if(ppk_button_element==null){
           //console.log('Adding mastodon ppk_button');
           var original_button_element=getFirstElementByClassName(parent_element,"button button--block");
           if(original_button_element!=null){
               ppk_button_element =  document.createElement('button');
               ppk_button_element.setAttribute('class', 'button button-send-ppk');
               ppk_button_element.innerHTML = original_button_element.innerHTML +'+';
               
               ppk_button_element.addEventListener("click", function() {
                  //console.log("ppk_button_element clicked");
                  var text_element=getFirstElementByClassName(document,"autosuggest-textarea__textarea");

                  replaceTextWithAllPPkCode(
                        text_element.value,
                        false, 
                        "ActivityPub",
                        function(new_text){ 
                            if(new_text!=null)
                                text_element.value  = new_text;
                              
                            original_button_element.click();
                        }
                     );
                  
               });
               
               parent_element.insertBefore(ppk_button_element, original_button_element);
              
               original_button_element.style.display = 'none';
           }
        }else{
           //console.log('Exist  mastodon ppk_button');
        }
    }
}

async function replaceTextWithAllPPkCode(txt_html, use_html, sns_type,callback){
    var new_text = replaceTextWithOdinPayCode(txt_html, use_html );
    if(new_text==null)
        new_text = txt_html;
    
    new_text = await replaceTextWithPPkRedirectCode(new_text, use_html,sns_type );
    
    callback(new_text);
}

//testtext @ppk:2021 $ppk:2021 @ppk：2021 $ppk：2021 @ppk:106 @ppk:106256
function replaceTextWithOdinPayCode(txt_html, use_html, spec_link_class ){
    //console.log("replaceTextWithOdinPayCode","text="+txt_html);
    txt_html = txt_html.replaceAll( "：", ":"); 
    
    var old_len = txt_html.length;
    
    //ODIN pay code
    var matched_ppk_uris = fetchPPkURIs(txt_html,"$");
    if(matched_ppk_uris!=null ){
        for(var kk=0;kk<matched_ppk_uris.length; kk++){
            var tmp_odin_uri = matched_ppk_uris[kk];

            var tmp_odinpay_url = "https://ppk001.sinaapp.com/odin/?me=" + encodeURIComponent(tmp_odin_uri);
            
            var replace_str = use_html ?
                       "[ " + tmp_odin_uri  +  " 的数字资产转账链接 <a href='"+tmp_odinpay_url+"' class='"+spec_link_class+"' target='_blank'>"+cutString(tmp_odinpay_url,30)+"</a> ]"
                      : "[ " + tmp_odin_uri  +  " 的数字资产转账链接 "+tmp_odinpay_url+" ]";
            
            txt_html = txt_html.replaceAll( "$"+tmp_odin_uri, replace_str);
        }
        
        //console.log("replaceTextWithOdinPayCode","new text="+txt_html);
    }
    
    return txt_html.length==old_len ? null:txt_html ;
    
}

//testtext @ppk:2021 $ppk:2021 @ppk：2021 $ppk：2021 
async function replaceTextWithPPkRedirectCode(txt_html, use_html, sns_type){
    //console.log("replaceTextWithPPkRedirectCode","text="+txt_html);

    txt_html = txt_html.replaceAll( "：", ":"); 
    var old_len = txt_html.length;
    
    var matched_ppk_uris = fetchPPkURIs(txt_html,"@");
    if(matched_ppk_uris!=null ){
        for(var kk=0;kk<matched_ppk_uris.length; kk++){
            var tmp_odin_uri = matched_ppk_uris[kk];
            //console.log("replaceMastodonTextWithPPkCode","redirect @"+tmp_odin_uri);

            var tmp_sns_id=null;

            var couter=0;
            while(couter<50){
                //console.log("replaceTextWithPPkRedirectCode[@"+tmp_odin_uri+"] couter="+couter);
                tmp_sns_id = getOdinRedirectSnsId(tmp_odin_uri,sns_type);
                if(tmp_sns_id!=null)
                    break;
                
                await sleepInAsyncFunction(100);
                couter++;
            }
            
            if(tmp_sns_id!=null){
                var replace_str = use_html ?
                           "[ <a href='"+tmp_sns_id+"' target='_blank'>@" + tmp_sns_id  +  " ("+tmp_odin_uri+") ]"
                          : "[ @" + tmp_sns_id  +  " ("+tmp_odin_uri+") ]";
                
                txt_html = txt_html.replaceAll( "@"+tmp_odin_uri, replace_str);
            }
        }
        
        //console.log("replaceTextWithPPkRedirectCode","new text="+txt_html);
    }
    
    
    return txt_html.length==old_len ? null:txt_html ;
    
}

function updateForMastodonListClass( root_class_name ) {
    //console.log("updateForMastodonListClass("+ root_class_name +") ");
    
    var root_elements = document.getElementsByClassName(root_class_name); 
    //console.log("updateForMastodonListClass() root_elements.length="+root_elements.length );
    
    for (var i=0, len=root_elements.length|0; i<len; i=i+1|0) {
        var display_name_element=getFirstElementByClassName(root_elements[i],"display-name__html");
        if(display_name_element!=null){
            //console.log("updateForMastodonListClass() root_elements["+i+"]="+display_name_element.textContent );
            var matched_ppk_uris = fetchPPkURIs(display_name_element.textContent);
            if(matched_ppk_uris!=null && matched_ppk_uris[0].length >0){
                var tmp_ppk_uri = matched_ppk_uris[0];
                //console.log("updateForMastodonListClass() matched="+tmp_ppk_uri );
                
                var result_data=pendingOdinInfo(tmp_ppk_uri);
                if(result_data!=null){
                    var display_account_element=getFirstElementByClassName(root_elements[i],"display-name__account");
                    if(display_account_element!=null){
                        var tmp_sns_id = display_account_element.textContent;
                        if(isSameSnsUser("ActivityPub",tmp_sns_id,window.location.host,result_data.x_sns)) {
                            display_account_element.innerHTML="@"+tmp_ppk_uri;
                            
                            display_name_element.innerHTML=result_data.name;
                            var account_avatar_element=getFirstElementByClassName(root_elements[i],"account__avatar");
                            if(account_avatar_element!=null){
                                //Normal toot
                                account_avatar_element.style.backgroundImage="url('"+result_data.avatar+"')";
                            }else{
                                //Re toot
                                account_avatar_element=getFirstElementByClassName(root_elements[i],"account__avatar-overlay-base");
                                if(account_avatar_element!=null){
                                    account_avatar_element.style.backgroundImage="url('"+result_data.avatar+"')";
                                }
                            }
                            
                        }else{
                            display_name_element.innerHTML="奥丁号有误或待更新";
                        }
                        
                    }
                }
            }
        }
    }
}

function updateForMastodonNotifTitle(){
    //console.log("updateForMastodonNotifTitle() ");
    
    var root_elements = document.getElementsByClassName("notification"); 
    //console.log("updateForMastodonNotifTitle() root_elements.length="+root_elements.length );
    
    for (var i=0, len=root_elements.length|0; i<len; i=i+1|0) {
      var display_name_element=getFirstElementByClassName(root_elements[i],"notification__display-name");
      if(display_name_element!=null){
        //console.log("updateForMastodonNotifTitle() root_elements["+i+"]="+display_name_element.textContent );
        var matched_ppk_uris = fetchPPkURIs(display_name_element.textContent);
        if(matched_ppk_uris!=null && matched_ppk_uris[0].length >0){
            var tmp_ppk_uri = matched_ppk_uris[0];
            console.log("updateForMastodonNotifTitle() matched="+tmp_ppk_uri );
            
            var result_data=pendingOdinInfo(tmp_ppk_uri);
            if(result_data!=null){
              var tmp_sns_id = display_name_element.title;
              if(isSameSnsUser("ActivityPub",tmp_sns_id,window.location.host,result_data.x_sns)) {
                display_name_element.innerHTML=result_data.name ; // + " ("+tmp_ppk_uri+")";
                
                //for favourite or retoot overlay
                var account_avatar_element=getFirstElementByClassName(root_elements[i],"account__avatar-overlay-overlay");
                if(account_avatar_element!=null){
                    //console.log("updateForMastodonNotifTitle() matched account__avatar-overlay-overlay:"+result_data.avatar );
                    account_avatar_element.style.backgroundImage="url('"+result_data.avatar+"')";
                }
              }else{
                display_name_element.innerHTML="未知奥丁号";  
              }
            }
         }
      }
    }
    
}

function updateForMastodonAccountHeader( ) {
    //console.log("updateForMastodonAccountHeader() ");
    
    var root_elements = document.getElementsByClassName("account__header"); 
    //console.log("updateForMastodonAccountHeader() root_elements.length="+root_elements.length );
    
    for (var i=0, len=root_elements.length|0; i<len; i=i+1|0) {
        var tmp_block_element=getFirstElementByClassName(root_elements[i],"account__header__tabs__name");
        if(tmp_block_element!=null){
          display_name_element=getFirstElementByTagName(tmp_block_element,"span");
          if(display_name_element!=null){
            //console.log("updateForMastodonAccountHeader() root_elements["+i+"]="+display_name_element.textContent );
            var matched_ppk_uris = fetchPPkURIs(display_name_element.textContent);
            if(matched_ppk_uris!=null && matched_ppk_uris[0].length >0){
                var tmp_ppk_uri = matched_ppk_uris[0];
                //console.log("updateForMastodonAccountHeader() matched="+tmp_ppk_uri );
                
                var result_data=pendingOdinInfo(tmp_ppk_uri);
                if(result_data!=null){
                    var display_account_element=getFirstElementByTagName(tmp_block_element,"small");
                    if(display_account_element!=null){
                      var tmp_sns_id = display_account_element.textContent;
                      if(isSameSnsUser("ActivityPub",tmp_sns_id,window.location.host,result_data.x_sns)) {
                        display_account_element.innerHTML="@"+tmp_ppk_uri + " -> " + display_account_element.innerHTML;
                    
                        display_name_element.innerHTML=result_data.name;
                        var account_avatar_element=getFirstElementByClassName(root_elements[i],"account__avatar");
                        if(account_avatar_element!=null){
                            account_avatar_element.style.backgroundImage="url('"+result_data.avatar+"')";
                        }
                      }
                    }
                }
              }
            }
        }
    }
}


function updateForMastodonText( root_class_name ) {
    console.log("updateForMastodonText("+ root_class_name +") ");
    
    var root_elements = document.getElementsByClassName(root_class_name); 
    //console.log("updateForMastodonText() root_elements.length="+root_elements.length );
    
    for (var i=0, len=root_elements.length|0; i<len; i=i+1|0) {
        var txt_html = replaceTextWithOdinPayCode( root_elements[i].innerHTML,true,'status-link unhandled-link' );
        if(txt_html!=null ){
            root_elements[i].innerHTML = txt_html;
        }
    }
}

//for SinaWeibo
function updateForSinaWeibo( ) {
    console.log("updateForSinaWeibo() ");
    
    updateForSinaWeiboSendEvent();
    
    updateForSinaWeiboListClass("WB_feed_detail");
    updateForSinaWeiboText("WB_text W_f14");
}

function updateForSinaWeiboSendEvent(  ){
    var root_element=getFirstElementByClassName(document,"send_weibo");
    
    if(root_element!=null){
      var parent_element=getFirstElementByClassName(root_element,"func");
    
      if(parent_element!=null){
        var ppk_button_element=getFirstElementByClassName(parent_element,"W_btn_a btn_30px button-send-ppk");
        if(ppk_button_element==null){
           //console.log('Adding SinaWeibo ppk_button');
           var original_button_element=getFirstElementByClassName(parent_element,"W_btn_a");
           if(original_button_element!=null){
               ppk_button_element =  document.createElement('button');
               ppk_button_element.setAttribute('class', 'W_btn_a btn_30px button-send-ppk');
               ppk_button_element.innerHTML = original_button_element.innerHTML +'+';
               
               ppk_button_element.addEventListener("click", function() {
                  //console.log("ppk_button_element clicked");
                  var text_element=getFirstElementByClassName(root_element,"W_input");

                  replaceTextWithAllPPkCode(
                        text_element.value,
                        false, 
                        "weibo.com",
                        function(new_text){ 
                            if(new_text!=null)
                                text_element.value  = new_text;
                              
                            original_button_element.click();
                        }
                     );
                  
               });
               
               parent_element.insertBefore(ppk_button_element, original_button_element);
              
               original_button_element.style.display = 'none';
           }
        }else{
           //console.log('Exist  mastodon ppk_button');
        }
      }
    }
}

function updateForSinaWeiboListClass( root_class_name ) {
    var root_elements = document.getElementsByClassName(root_class_name); 
    //console.log("updateForSinaWeiboListClass() root_elements.length="+root_elements.length );
    
    for (var i=0, len=root_elements.length|0; i<len; i=i+1|0) {
        var display_name_element=getFirstElementByClassName(root_elements[i],"W_fb");
        if(display_name_element!=null){
            //console.log("updateForSinaWeibo() root_elements["+i+"]="+ display_name_element.toString() );
            var tmp_display_name = display_name_element.innerHTML.replace("ppk_","@ppk:")
            var matched_ppk_uris = fetchPPkURIs(tmp_display_name);
            if(matched_ppk_uris!=null && matched_ppk_uris[0].length >0){
                var tmp_ppk_uri = matched_ppk_uris[0];
                //console.log("updateForSinaWeibo() matched="+tmp_ppk_uri );
                
                var result_data=pendingOdinInfo(tmp_ppk_uri);
                if(result_data!=null){
                    display_name_element.innerHTML = tmp_display_name.replace("ppk:","<span>ppk</span>:") + " (" +result_data.name +")";
                    var account_avatar_element=getFirstElementByClassName(root_elements[i],"W_face_radius");
                    if(account_avatar_element!=null){
                        account_avatar_element=getFirstElementByClassName(account_avatar_element,"W_face_radius");
                        if(account_avatar_element!=null){
                            account_avatar_element.src=result_data.avatar;
                        }
                    }
                }
            }
        }
    }
    
}

function updateForSinaWeiboText( root_class_name ) {
    console.log("updateForSinaWeiboText("+ root_class_name +") ");
    
    var root_elements = document.getElementsByClassName(root_class_name); 
    //console.log("updateForSinaWeiboText() root_elements.length="+root_elements.length );
    
    for (var i=0, len=root_elements.length|0; i<len; i=i+1|0) {
        var txt_html = root_elements[i].innerHTML.replace( /<a [^>]*>@ppk<\/a>/gi,'@ppk' );
        
        txt_html = replaceTextWithOdinPayCode( txt_html,true );
        if(txt_html!=null ){
            root_elements[i].innerHTML = txt_html;
        }
    }
}


//for Binance
function updateForExchangeBinance( ) {
  console.log("updateForExchangeBinance() ");
  
  updateForExchangeBinanceWithdrawEvent();
}

function updateForExchangeBinanceWithdrawEvent(  ){
  var parent_element=getFirstElementByClassName(document,"css-1f2xe1g");

  if(parent_element!=null){
    console.log('Found Binance withdraw element ');
    var ppk_button_element=getFirstElementByClassName(parent_element,"icon-input-ppk");
    if(ppk_button_element==null){
       console.log('Adding withdraw ppk_button');
       var original_button_element=getFirstElementByClassName(parent_element,"css-8rpvaj");
       if(original_button_element!=null){
           ppk_button_element =  document.createElement('button');
           ppk_button_element.setAttribute('class', 'icon-input-ppk ppk-bg');
           ppk_button_element.innerHTML = '+P';
           
           ppk_button_element.addEventListener("click", function() {
              //console.log("ppk_button_element clicked");
              var text_element=getFirstElementByTagName(parent_element,"input");

              showSelectWalletAddressPanel();
              /*
              replaceWithdrawAddressWithPPkCode(
                    text_element.value,
                    "ppk:btc/", 
                    function(new_address){ 
                        console.log("updateForExchangeBinanceWithdrawEvent","use address "+new_address);
                        if(new_address!=null){
                            //text_element.value  = new_address;
                            text_element.setAttribute('value',new_address);
                            //$(".css-1vgh1xx").val(new_address);
                            //$(".css-1vgh1xx").prop('value',new_address);
                        }
                    }
                 );
              */
           });
           
           parent_element.appendChild(ppk_button_element);
          
           //original_button_element.style.display = 'none';
       }
    }else{
       //console.log('Exist  mastodon ppk_button');
    }
  }
}


function showSelectWalletAddressPanel()
{
  var panel = document.getElementById('ppk-plugin-select-address-panel');
      
  if(panel!=null){
    panel.style.display="block";
    return;
  }
  
  getCurrentUserByBackground(function(status,result){
      var tmp_ppk_uri="";
      if(status=="OK"){
        tmp_ppk_uri=result.uri;
      }
      /*
      var result_data=pendingOdinInfo(tmp_ppk_uri);

      if(result_data==null || result_data.x_wallets==null)
          return null;
      console.log("showSelectWalletAddressPanel","result_data.x_wallets=", JSON.stringify(result_data.x_wallets));
      */
      
      var select_page_url = chrome.extension.getURL("select.html");

      var panel=document.createElement('div');
      panel.id = 'ppk-plugin-select-address-panel';
      panel.className = 'ppk-plugin-select-address-panel ppk-bg';
      panel.innerHTML = `
      <h3>选择奥丁号关联的钱包地址：</h3>
      <button style="position: absolute;top: 0;right: 0;" id="btn-close-ppk-plugin-panel">X关闭</button>
      <iframe width="100%" height="80%" src="`+select_page_url+`?ppkpayto=`+ encodeURIComponent(tmp_ppk_uri) +`">
      </iframe>
    `;
      document.body.appendChild(panel);
      
      document.getElementById('btn-close-ppk-plugin-panel').addEventListener("click", function() {
        panel.style.display="none";
      });

  });
}

function getCurrentUserByBackground(callback){
  if(typeof chrome.app.isInstalled!=="undefined"){
    chrome.runtime.sendMessage(
        {
            "cmd": "get_current_user"
        }, 
        function(response) {
            if(response){
                //tip('getCurrentUserByBackground()：status=' + response.status + " result="+response.result);
                callback(response.status,response.result);
            }else{
                console.log('getCurrentUserByBackground()：invalid response:'+response);
            }
    });
  }
}

/*
async function replaceWithdrawAddressWithPPkCode(odin_uri, coin_type, callback){
  console.log("replaceWithdrawAddressWithPPkCode","odin_uri="+odin_uri+", coin_type="+coin_type);

  if( odin_uri==null || odin_uri.trim().length==0){
    odin_uri = prompt("请输入提现转账的目标奥丁号","ppk:");
  }
  
  if (odin_uri == null || odin_uri.trim().length==0) {
     return;
  }

  odin_uri = odin_uri.replaceAll( "：", ":"); 
  
  console.log("replaceWithdrawAddressWithPPkCode","searching address of "+odin_uri);

  var tmp_wallet_address=null;

  var couter=0;
  while(couter<50){
      console.log("replaceWithdrawAddressWithPPkCode["+odin_uri+"] couter="+couter);
      tmp_wallet_address = getOdinBindedWalletAddress(odin_uri,coin_type);
      if(tmp_wallet_address!=null)
          break;
      
      await sleepInAsyncFunction(100);
      couter++;
  }
  
  console.log("replaceWithdrawAddressWithPPkCode","matched address "+tmp_wallet_address);
  if(tmp_wallet_address!=null){
      callback(tmp_wallet_address);
      showSelectWalletAddressPanel();
  }
}

function getOdinBindedWalletAddress(tmp_odin_uri,coin_type){
  return "1test1234567";
}
*/
    
function parseRespPPkData(status,result){
    var odin_name = "Anonymous";
    var odin_avatar = "https://tool.ppkpub.org/image/user.png";
    var x_sns = null;
    var x_wallets=null;
    
    if('OK'==status){
        try{
            var obj_pttp_data = parseJsonObjFromAjaxResult(result);
            var tmp_content = getContentFromData(obj_pttp_data);
            //console.log("parseRespPPkData","pttp_content="+tmp_content);
            
            var obj_content = JSON.parse( tmp_content );
            
            if(typeof(obj_content) == 'undefined' || obj_content==null){
                odin_name = "不存在的奥丁号或者解析有误！";
            }else if(typeof(obj_content.x_did) != 'undefined' ){
                var obj_did = obj_content.x_did;
                if(typeof(obj_did.name) != 'undefined' && obj_did.name!=null &&  obj_did.name.length>0 )
                    odin_name = obj_did.name;
                
                if(typeof(obj_did.avatar) != 'undefined' ){
                    //console.log("obj_did.avatar="+obj_did.avatar);
                    
                    odin_avatar = obj_did.avatar;
                }
                
                if( typeof(obj_content.x_sns)!= 'undefined' ){
                    x_sns = obj_content.x_sns;
                }
                
                if( typeof(obj_content.x_wallets)!= 'undefined' ){
                    x_wallets = obj_content.x_wallets;
                }
                
                m_bookGetPPkDataOK=true;
            }
        }catch(error){
            console.log("getPPkDataCallback() error:"+error);
            odin_name = "奥丁号数据有误！";
        }
    }else{
        odin_name = "未能获得奥丁号信息！";
    }
    return {"name":odin_name,"avatar":odin_avatar,"x_sns":x_sns,"x_wallets":x_wallets};
}

function getPPkDataByBackground(dest_ppk_uri,callback, use_cache){
  if(typeof chrome.app.isInstalled!=="undefined"){
    chrome.runtime.sendMessage(
        {
            "cmd": "get_ppk_data",
            "uri": dest_ppk_uri,
            "use_cache": use_cache
        }, 
        function(response) {
            if(response){
                //tip('getPPkDataByBackground()：status=' + response.status + " result="+response.result);
                callback(response.status,response.result);
            }else{
                //tip('getPPkDataByBackground()：invalid response['+dest_ppk_uri+']='+response);
                console.log('getPPkDataByBackground()：invalid response['+dest_ppk_uri+']='+response);
            }
    });
  }
}

function delPPkCacheByBackground(dest_ppk_uri){
  chrome.runtime.sendMessage(
    {
        "cmd": "del_ppk_cache",
        "uri": dest_ppk_uri
    }, 
    function(response) {
        //tip('getPPkDataByBackground()：invalid response['+dest_ppk_uri+']='+response);
        console.log('delPPkCacheByBackground','response='+JSON.stringify(response) );
  });
}

function getContentFromData(obj_resp){
    //console.log("getContentFromData() result uri=",obj_resp.uri);
    
    if(obj_resp==null){
        return null;
    }
        
    obj_metainfo= parseJsonObjFromAjaxResult(obj_resp.metainfo); 
    
    if( obj_metainfo!=null && obj_metainfo.status_code==200){
        var content=obj_resp.content;
        //console.log("getContentFromData() uri=",obj_resp.uri+"\ntype=",obj_metainfo.content_type," \nlength=",obj_metainfo.content_length);

        return content;
    }else{
        var str_err = "PTTP status : "+obj_metainfo.status_code +" ";
        if( obj_metainfo!=null && obj_metainfo.hasOwnProperty('status_detail')){
            str_err += obj_metainfo.status_detail;
        }
        console.log(str_err);
        return null;
    }
}

/**
 * 将AJAX的结果转换为JSON对象
 */
function parseJsonObjFromAjaxResult(result){
    if(typeof result != 'string')
        return result;
    try{
        return JSON.parse( result );
    }catch(e){
        console.log("Meet invalid json string : "+result);
        return null;
    }
}

/**参数说明： 
 * 根据长度截取先使用字符串，超长部分追加… 
 * str 对象字符串 
 * len 目标字节长度 
 * 返回值： 处理结果字符串 
 */ 
function cutString(str, len) { 
   //length属性读出来的汉字长度为1 
   if(str.length*2 <= len) { 
     return str; 
   } 
   var strlen = 0; 
   var s = ""; 
   for(var i = 0;i < str.length; i++) { 
     s = s + str.charAt(i); 
     if (str.charCodeAt(i) > 128) { 
       strlen = strlen + 2; 
       if(strlen >= len){ 
         return s.substring(0,s.length-1) + "..."; 
       } 
     } else { 
       strlen = strlen + 1; 
       if(strlen >= len){ 
         return s.substring(0,s.length-2) + "..."; 
       } 
     } 
   } 
   return s; 
} 

function fetchPPkURIs(str,add_prefix){
    var pattern_str = typeof(add_prefix)!="undefined" && add_prefix!=null ? "["+add_prefix+"]" : "";
    pattern_str +="[pP][pP][kK]:\\w+([\\w-./]*)?";
    var pattern = new RegExp(pattern_str,'g');
	var tmp_array = str.match(pattern);
    if(tmp_array==null || tmp_array.length == 0)
        return null;
    
    var result_array=[];
    for(var kk=0;kk<tmp_array.length; kk++){
        var odin_uri=tmp_array[kk];
        //console.log("fetchPPkURIs","["+kk+"] =  "+odin_uri);
        if(typeof(odin_uri)!="undefined" && odin_uri!=null){
            if(typeof(add_prefix)!="undefined" && add_prefix!=null )
                odin_uri = odin_uri.substring( add_prefix.length );

            //odin_uri = ODIN.formatPPkURI(odin_uri,false);
            if(odin_uri!=null  && result_array.indexOf(odin_uri)<0 )
                result_array.push(odin_uri);
        }
    }

    //待从大到小排序
    result_array.reverse();
    
    //console.log("fetchPPkURIs","result="+ JSON.stringify(result_array) );
    
    return result_array;
}

function getFirstElementByClassName(root_element,class_name){
    if(root_element==null)
        return null;
    
    var tmp_elements = root_element.getElementsByClassName(class_name); 
    
    return (tmp_elements!=null && tmp_elements.length>0 ) ?  tmp_elements[0]:null;
}

function getFirstElementByTagName(root_element,tag_name){
    var tmp_elements = root_element.getElementsByTagName(tag_name); 
    
    return (tmp_elements!=null && tmp_elements.length>0 ) ?  tmp_elements[0]:null;
}

function sleepInAsyncFunction(millisecond) {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve()
        }, millisecond)
    })
}

//提取字符串里的 ppk: 起始的网址
function isSameSnsUser(sns_type, sns_name, sns_host_domain,odin_sns_set){
  //console.log("isSameSnsUser",sns_type+" , "+sns_name+" , "+sns_host_domain + " , "+JSON.stringify(odin_sns_set)   );

  if(sns_name==null || odin_sns_set==null)
      return false;
  
  sns_name=sns_name.trim();

  if(sns_name.indexOf('@')==0){//去掉开头的@字符
      sns_name = sns_name.substring(1);
  }
  
  if ( sns_name.indexOf('@')<0 && sns_host_domain!=null) {
      sns_name = sns_name + "@"+sns_host_domain ;
  }

  var tmp_ids = odin_sns_set[sns_type];
  if( typeof(tmp_ids)=="undefined" || tmp_ids==null)
      return false;

  for(var kk=0; kk<tmp_ids.length; kk++  ){
      //console.log("isSameSnsUser"," tmp_ids["+kk+"]="+tmp_ids[kk] );
      if( sns_name === tmp_ids[kk] )
          return true;
  }

  return false;
}

// 主动发送消息给后台
// 要演示此功能，请打开控制台主动执行sendMessageToBackground()
function sendMessageToBackground(message) {
	chrome.runtime.sendMessage({greeting: message || '你好，我是content-script呀，我主动发消息给后台！'}, function(response) {
		tip('收到来自后台的回复：' + response);
	});
}

// 监听长连接
chrome.runtime.onConnect.addListener(function(port) {
	console.log(port);
	if(port.name == 'test-connect') {
		port.onMessage.addListener(function(msg) {
			console.log('收到长连接消息：', msg);
			tip('收到长连接消息：' + JSON.stringify(msg));
			if(msg.question == '你是谁啊？') port.postMessage({answer: '我是你爸！'});
		});
	}
});

window.addEventListener("message", function(e)
{
	console.log('收到消息：', e.data);
	if(e.data && e.data.cmd == 'invoke') {
		eval('('+e.data.code+')');
	}
	else if(e.data && e.data.cmd == 'message') {
		tip(e.data.data);
	}
}, false);


function initCustomEventListen() {
	var hiddenDiv = document.getElementById('myCustomEventDiv');
	if(!hiddenDiv) {
		hiddenDiv = document.createElement('div');
		hiddenDiv.style.display = 'none';
		hiddenDiv.id = 'myCustomEventDiv';
		document.body.appendChild(hiddenDiv);
	}
	hiddenDiv.addEventListener('myCustomEvent', function() {
		var eventData = document.getElementById('myCustomEventDiv').innerText;
		tip('收到自定义事件：' + eventData);
	});
}

var tipCount = 0;
// 简单的消息通知
function tip(info) {
	info = info || '';
	var ele = document.createElement('div');
	ele.className = 'chrome-plugin-simple-tip slideInLeft';
	ele.style.top = tipCount * 70 + 20 + 'px';
	ele.innerHTML = `<div>${info}</div>`;
	document.body.appendChild(ele);
	ele.classList.add('animated');
	tipCount++;
	setTimeout(() => {
		ele.style.top = '-100px';
		setTimeout(() => {
			ele.remove();
			tipCount--;
		}, 400);
	}, 3000);
}