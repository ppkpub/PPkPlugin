const HISTORY_KEY="history-appdemo-pay-dest";
const HISTORY_MAX_SIZE=3;
const APPDEMO_MARK = "PPkAppDemo(https://tool.ppkpub.org/demo/pay/)";

var mObjWallets;
var mBoolRefreshAddressing=false;

window.onload=function(){
    var str_dest = getQueryString('ppkpayto');
    if(str_dest!=null && str_dest.length>0){
        document.getElementById('dest_odin_uri').value = str_dest;
    }
    
    $('#btn_copyAddress').click(function(event){ copyAddressToClipboard(); });
    $('#btn_refreshDestInfo').click(function(event){ refreshDestInfo(true); });
    
    $('#dest_odin_uri').change(function(event){ refreshDestInfo(false);return false; });
    $('#dest_wallet_list').change(function(event){ copyAddressToClipboard(); });
    
    
    refreshDestInfo(false);
}

function refreshDestInfo(clear_cache){
    if(mBoolRefreshAddressing)
        return;
    
    mObjWallets = null;
    document.getElementById("dest_wallet_list").options.length=0;

    var str_dest = document.getElementById("dest_odin_uri").value.trim();
    if(str_dest.length==0){
        showHistory();
        document.getElementById("dest_wallet_list").options.add(new Option("请先输入或选择一个奥丁号标识(以ppk:起始)",""));
        return;
    }
    
    var dest_odin_uri=PPKLIB.formatPPkURI(str_dest,false);
    
    if(dest_odin_uri==null){
        commonAlert("请输入有效的奥丁号标识(以ppk:起始)");
        showHistory();
        return;
    }
    
    document.getElementById('dest_odin_uri').readonly = true;
    document.getElementById("dest_odin_uri").value = dest_odin_uri;
    waitingButton("btn_refreshDestInfo");
    mBoolRefreshAddressing=true;

    //更新输入历史
    try{
        var historyArray = getHistory();

        var exist = historyArray.indexOf(dest_odin_uri);
        if(exist<0){
            historyArray.push(dest_odin_uri);
        }
        
        if(historyArray.length>HISTORY_MAX_SIZE){
            historyArray.splice(0, historyArray.length-HISTORY_MAX_SIZE);
        }
        
        saveLocalConfigData(HISTORY_KEY,JSON.stringify(historyArray));
    } catch (error) {
      console.error(error);
    }
    
    showHistory();

    //获取标识解析数据
    document.getElementById("dest_wallet_list").options.add(new Option("正在获取关联地址，请稍等...",""));
    
    //if(clear_cache)
    //    PPKLIB.deleteCache(str_dest);

    PPKLIB.getPPkData(dest_odin_uri,myPPkDataCallback, !clear_cache);

}

function myPPkDataCallback(status,result){
    if('OK'==status){
        obj_pttp_data = parseJsonObjFromAjaxResult(result);
        
        //document.getElementById("debug_data").value=JSON.stringify(obj_pttp_data);
        var tmp_content = PPKLIB.getContentFromData(obj_pttp_data);
        //document.getElementById("debug_data").value=tmp_str;
        var obj_content = null;
        try{
            obj_content = JSON.parse( tmp_content );
        }catch(error){
            console.log("myPPkDataCallback() error:"+error);
        }
        
        document.getElementById("dest_wallet_list").options.length=0;
        if(typeof(obj_content) == 'undefined' || obj_content==null){
            document.getElementById("dest_wallet_list").options.add(new Option("不存在的标识或者解析有误，请刷新下试试",""));
        }else if(typeof(obj_content.x_wallets) == 'undefined'){
            document.getElementById("dest_wallet_list").options.add(new Option("尚未设置",""));
        }else{
            mObjWallets = obj_content.x_wallets;
            //document.getElementById("debug_data").value=JSON.stringify(mObjWallets);
            
            //document.getElementById("dest_wallet_list").options.add(new Option("请选择币种和地址生成对应转账码",""));
            Object.keys(mObjWallets).forEach(function(tmp_chain_uri){
                var tmp_wallet_set = mObjWallets[tmp_chain_uri];
                var tmp_option = new Option("["+tmp_chain_uri+"] "+tmp_wallet_set['label']+" - "+shortCoinAddress(tmp_wallet_set['address'])
                                            ,tmp_chain_uri);
                document.getElementById("dest_wallet_list").options.add(tmp_option);
                
                /*
                if( tmp_chain_uri == document.getElementById("current_eth_chain_uri").value ){
                    document.getElementById("dest_eth_address").value=tmp_wallet_set['address'];
                }else if(tmp_chain_uri == "ppk:joy/mov/"){
                    document.getElementById("dest_mov_address").value=tmp_wallet_set['address'];
                }else if(tmp_chain_uri == "ppk:bch/"){
                    document.getElementById("dest_bch_address").value=tmp_wallet_set['address'];
                }
                */
            });
            
            //copyAddressToClipboard(   );
        }
        finishedButton("btn_refreshDestInfo");
    }else{
        document.getElementById("dest_wallet_list").options.length=0;
        document.getElementById("dest_wallet_list").options.add(new Option("出错了，请重试",""));
        //enableButton("btn_refreshDestInfo","出错了，请重试");
    }
    
    mBoolRefreshAddressing=false;
    document.getElementById('dest_odin_uri').readonly = false;
    
}

function copyAddressToClipboard(   ){
    var tmp_chain_uri = document.getElementById("dest_wallet_list").value;
    console.log("selected: "+tmp_chain_uri);
    
    if( tmp_chain_uri==null || tmp_chain_uri.length==0 ){
        return;
    }
    
    var tmp_wallet_set = mObjWallets[tmp_chain_uri];
    

    //document.getElementById("scan_coin_type").innerHTML = "收款币种: [" + tmp_chain_uri + "] "+tmp_wallet_set['label'] ;
    //document.getElementById("scan_address").innerHTML =  "收款地址: " +tmp_wallet_set['address'];
    
    copyToClipboard(tmp_wallet_set['address'],"已复制到剪贴板");
}

function showHistory( ){
    var historyArray=getHistory();
    //myAlert(historyArray);
    if(historyArray.length==0){
        return;
    }
    str_html="<strong>最近的收款人</strong>:<br> ";
    for(kk=historyArray.length-1;kk>=0;kk--){
        str_html += "<a  class='btn btn-default btn-xs' role='button' id='btn_history"+kk+"' >"+historyArray[kk]+"</a> "
    }
    document.getElementById('history_odins').innerHTML=str_html;
    
    for(kk=historyArray.length-1;kk>=0;kk--){
        $('#btn_history'+kk).click(function(event){ useHistory( event.currentTarget.innerHTML ); });
    }
}

function useHistory(str_old_odin){
    if(mBoolRefreshAddressing)
        return;
        
    document.getElementById('dest_odin_uri').value = str_old_odin ;
    refreshDestInfo(false);
}

function getHistory( ){
    try {
        var historyStr=getLocalConfigData(HISTORY_KEY);
        //myAlert(historyStr);
        if(historyStr==null){
            return new Array();
        }else{
            return JSON.parse(historyStr);
        }
    } catch (error) {
      console.error(error);
      return new Array();
    }
}

//缩短显示长地址,待公共库生效后可以删除
function shortCoinAddress(str_address){
    if(!str_address)
        return "unknown";
    
    if(str_address.length<=13){
        return str_address;
    }
    
    return str_address.substring(0,6)+'...'+str_address.substring(str_address.length-4);
}

function copyToClipboard(content, message) {
    var aux = document.createElement("input"); 
    aux.setAttribute("value", content); 
    document.body.appendChild(aux); 
    aux.select();
    document.execCommand("copy"); 
    document.body.removeChild(aux);
    if (message == null) {
        showTip("复制成功","success");
    } else{
        showTip(message,"success");
    }
}

//自动消失的提示信息，type:'success'是成功信息，'danger'是失败信息,'info'是普通信息,'warning'是警告信息
function showTip(tip, type) {
    var $tip = $('#tip');
    $tip.stop(true).prop('class', 'alert alert-' + type).text(tip).css('margin-left', - $tip.outerWidth() / 2).fadeIn(500).delay(2000).fadeOut(500);
}